## Project Guidelines

### 1. Project Setup Guideline
Adding soon

### 2. Coding Standard Guidelines
Adding soon

### 3. Security Guidelines
Adding soon

### 4. Performance Guidelines
Adding soon

### 5. Code Audit Guidelines
Adding soon

### 6. Deployment Guidelines
Adding soon