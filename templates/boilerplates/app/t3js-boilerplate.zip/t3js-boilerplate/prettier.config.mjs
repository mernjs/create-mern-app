/** @type {import('prettier').Config & import('prettier-plugin-tailwindcss').options} */

export default {
	plugins: ["prettier-plugin-tailwindcss"],
};