## Project Guidelines

### Guideline 1 - Project Setup Guideline
Adding soon

### Guideline 2 - Coding Standard Guidelines
Adding soon

### Guideline 3 - Security Guidelines
Adding soon

### Guideline 4 - Performance Guidelines
Adding soon

### Guideline 5 - Code Audit Guidelines
Adding soon

### Guideline 6 - Deployment Guidelines
Adding soon