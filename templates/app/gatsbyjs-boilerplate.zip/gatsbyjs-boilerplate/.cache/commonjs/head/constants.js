"use strict";

exports.__esModule = true;
exports.VALID_NODE_NAMES = void 0;
const VALID_NODE_NAMES = [`link`, `meta`, `style`, `title`, `base`, `noscript`, `script`, `html`, `body`];
exports.VALID_NODE_NAMES = VALID_NODE_NAMES;
//# sourceMappingURL=constants.js.map