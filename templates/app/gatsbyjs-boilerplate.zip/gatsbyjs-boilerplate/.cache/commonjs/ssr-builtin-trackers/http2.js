"use strict";

const {
  wrapModuleWithTracking
} = require(`./tracking-unsafe-module-wrapper`);
module.exports = wrapModuleWithTracking(`http2`);
//# sourceMappingURL=http2.js.map