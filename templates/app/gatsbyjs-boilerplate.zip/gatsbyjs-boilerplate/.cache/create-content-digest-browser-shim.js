exports.createContentDigest = () => ``
