module.exports = {
    stories: ['./*.stories.js'],
};
