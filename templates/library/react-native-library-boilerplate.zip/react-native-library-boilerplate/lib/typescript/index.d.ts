declare const FBLoginButton: () => JSX.Element;
export default FBLoginButton;
//# sourceMappingURL=index.d.ts.map