const auth = require('./auth')
const isLoggedIn = require('./isLoggedIn')

module.exports = {
    auth: auth,
    isLoggedIn: isLoggedIn
}