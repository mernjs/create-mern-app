export const addTwoNumber = (a,b, callback) => {
    callback(parseInt(a) + parseInt(b))
}