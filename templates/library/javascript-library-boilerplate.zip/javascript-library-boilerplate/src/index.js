const addTwoNumber = () => {
    console.log("add tow number")
}
export { addTwoNumber };