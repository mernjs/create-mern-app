export const example = () => {
    return 'example function call'
}