import './App.css';
import { FBLoginButton } from 'react-library'

function App() {
    return (
        <div className="App">
            <header className="App-header">
                <FBLoginButton />
            </header>
        </div>
    );
}

export default App;
