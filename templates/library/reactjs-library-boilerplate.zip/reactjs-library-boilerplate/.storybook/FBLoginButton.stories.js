import React from 'react';
import { FBLoginButton } from '../src/index.js';

export default {
	component: FBLoginButton,
	title: 'FBLoginButton',
}

export const PrimaryButton = () => <FBLoginButton />