// index.js
import AuthService from './lib/auth';

export default AuthService;
