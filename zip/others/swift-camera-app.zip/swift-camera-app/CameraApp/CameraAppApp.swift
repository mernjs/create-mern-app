//
//  CameraAppApp.swift
//  CameraApp
//
//  Created by Development Hestabit on 30/04/24.
//

import SwiftUI

@main
struct CameraAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
