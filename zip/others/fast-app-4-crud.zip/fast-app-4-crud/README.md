mkdir fastapi-crud-app
cd fastapi-crud-app
python -m venv env
source env/bin/activate

