import SwiftUI

struct BlinkingView: View {
    var body: some View {
        Color.black.opacity(0.5)
            .ignoresSafeArea(.all)
    }
}
