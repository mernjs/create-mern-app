//
//  ContentView.swift
//  CameraApp
//
//  Created by Development Hestabit on 30/04/24.
//

import SwiftUI
import AVFoundation

struct ContentView: View {
    var body: some View {
        FileManagerView()
    }
}
