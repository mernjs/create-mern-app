//
//  ChatWithGeminiApp.swift
//  ChatWithGemini
//
//  Created by Vijay Pratap Singh on 01/06/24.
//

import SwiftUI

@main
struct ChatWithGeminiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
