import FBLoginButton from './components/FBLoginButton';

export { FBLoginButton };