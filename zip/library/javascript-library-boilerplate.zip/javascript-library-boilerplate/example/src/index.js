import { addTwoNumber } from 'javascript-library';
const textNode = document.createTextNode("JavaScript Library Example");

addTwoNumber()

const app = document.querySelector('#root')
app.append(textNode)