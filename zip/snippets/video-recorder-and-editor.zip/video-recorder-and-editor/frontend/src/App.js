import VideoEditor from './VideoEditor1';
import VideoRecorder from './VideoRecorder1';

function App() {
  // return <VideoEditor/>
  return <VideoRecorder/>
}

export default App;
