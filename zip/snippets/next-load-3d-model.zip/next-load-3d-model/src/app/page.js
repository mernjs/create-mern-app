"use client"
import ModelViewer from "@/components/ModelViewer";

export default function Home() {
  return (
    <main>
     <ModelViewer/>
    </main>
  );
}
