import React, { Component } from 'react';
import UserList from './components/UserList';

class App extends Component {
  	render() {
		return <UserList />
	}
}

export default App;